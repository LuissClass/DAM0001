package examen.com;

/**
 * @author Luis Esteban Velez Gonzalez
 * @version 1.2
 *
 * */
public class Alumno {
    /**
     * codigo es unico para cada instancia
     * numAl es el contador de instancias totales de Alumno
     * edad es un atributo que indica la edad del alumno
     * notas[] guarda las notas de los alumnos en dobules*/
    int codigo;
    static int numAl = 1;
    int edad;
    double notas[];

    /**
     * Da un valor predeterminado a los atributos de cada instancia de Alumno
     * las notas se generan automaticamente, de forma aleatoria
     * */
    Alumno() {
        edad = 33;
        codigo = numAl++;
        notas = new double[5];
        for (int i = 0; i < notas.length; i++) {
            notas[i] = (int) (Math.random() * 10 + 1);
        }
    }

    /**
     * Aumenta en 1 el valor del atributo edad
     * */
    void cumpleAgnos() {
        edad++;
    }

    /**
     * Sube de nota una nota especifica de un alumno en un incremento tambien especifico
     * @param inc es un numero entero que se suma en una de las notas[]
     * @param pos es la posicion de la nota en notas[]
     * @return retorna la nota que se ha aumentado
     * */

    int sumarANota(int pos, int inc) {
        notas[pos] += inc;
        return (int) notas[pos];
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public static void main(String[] args) {
        Alumno a = new Alumno();
    }
}

