package examen.com;

/**
 * @author Luis Esteban Velez Gonzalez
 * @version 1.2
 */
public class IES {
    /**
     * nombre indica el nombre del instituto
     * alumnos[] guarda todas las iteraciones de Alumnos que se vayan creando
     */
    String nombre = "IES Luis Vives";
    Alumno alumnos[];

    /**
     * genera 5 instancias de Alumno
     */
    IES() {
        alumnos = new Alumno[4];
        for (int i = 0; i < alumnos.length; i++)
            alumnos[i] = new Alumno();
    }


    int subirNotas() {
        int sum = 0;
        for (int i = 0; i < alumnos.length; i++)
            sum += alumnos[i].sumarANota(i + 1, i - 1);
        return sum;
    }


    private void cumplirAgnos() {
        int aleat;
        for (int i = 0; i < 3; i++) {
            aleat = (int) (Math.random() * 3);
            alumnos[aleat].cumpleAgnos();
        }
    }

    public static void main(String[] args) {
        IES ies = new IES();
        int s = ies.subirNotas();
        ies.cumplirAgnos();
    }
}
